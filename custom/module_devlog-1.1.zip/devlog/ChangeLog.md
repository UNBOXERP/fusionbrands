# CHANGELOG DEVLOG FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 1.0

Initial version

## 1.1

modificacion getNum
