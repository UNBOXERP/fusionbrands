# CHANGELOG UNBOXUTIL FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 1.0

Initial version

## 2.0

Added a new feature: Batches with FIFO

--> Next version: 3.0 New features: Stock No Negative transfer batch to next batch (with FIFO)
 ## 2.2

Added a new feature: Drag and drop to move Project Purchase Order in the tab Overview of Project

## 2.3 

Added a new feature : Invoice List with Paid in batch actions

## 2.4 

Fixed Bugs

## 2.5 

Added Paid in List of Invoices

## 2.5.1

Fix Bugs with all products with Batchs from Father to child and vice versa

## 5.0

Added Configuration in Setup, Variants and Clone Projects Fixes
