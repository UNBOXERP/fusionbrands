INSERT INTO llx_commande_fournisseurs_project_order ( id,order) VALUES ( 0 ,'dummy');
