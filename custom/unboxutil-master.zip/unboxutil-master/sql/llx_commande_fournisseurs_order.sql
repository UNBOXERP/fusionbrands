CREATE TABLE llx_commande_fournisseurs_project_order
(
    id      int(11) NOT NULL AUTO_INCREMENT,
    order text DEFAULT NULL,
    PRIMARY KEY (id)
)
ENGINE = INNODB;
