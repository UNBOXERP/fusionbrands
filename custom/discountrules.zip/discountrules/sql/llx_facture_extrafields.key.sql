ALTER TABLE llx_facture_extrafields ADD dsc varchar(50) NULL;
ALTER TABLE llx_facture_extrafields ADD dscv varchar(50) NULL;
ALTER TABLE llx_facture_extrafields ADD dscdocument varchar(50) NULL;
ALTER TABLE llx_facture_extrafields ADD dscvdocument varchar(50) NULL;
ALTER TABLE llx_facture_extrafields ADD dscdocuments varchar(50) NULL;
ALTER TABLE llx_facture_extrafields ADD dscvdocuments varchar(50) NULL;
ALTER TABLE llx_facture_extrafields ADD desctotal double(24,8) NULL;