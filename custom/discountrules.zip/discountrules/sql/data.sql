-- Copyright (C) 2018 John BOTELLA
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.


INSERT INTO llx_extrafields( name, label, type, pos, size, entity, elementtype, fieldunique, fieldrequired, param, alwayseditable, perms, langs, list, printable, fielddefault, fieldcomputed, fk_user_author, fk_user_modif, datec, enabled, help, totalizable ) VALUES('dscdocument', 'Discount Document %', 'varchar', 100, '50', 0, 'facture', 0, 0, 'a:1:{s:7:\"options\";a:1:{s:0:\"\";N;}}', 0, null, 'discountrules@discountrules', '1', '2', null, null, 1, 1,'2022-06-14 21:42:57', '1', 'Discount Document %', FALSE);
INSERT INTO llx_extrafields( name, label, type, pos, size, entity, elementtype, fieldunique, fieldrequired, param, alwayseditable, perms, langs, list, printable, fielddefault, fieldcomputed, fk_user_author, fk_user_modif, datec, enabled, help, totalizable ) VALUES('dscvdocument', 'Discount Document Total', 'varchar', 100, '50', 0, 'facture', 0, 0, 'a:1:{s:7:\"options\";a:1:{s:0:\"\";N;}}', 0, null, 'discountrules@discountrules', '1', '2', null, null, 1, 1,'2022-06-14 21:48:57', '1', 'Discount Document Value', FALSE);
INSERT INTO llx_extrafields( name, entity, label, type, size, elementtype, fieldunique, fieldrequired, perms, langs, pos, alwayseditable, param, list, printable, totalizable, fielddefault, fieldcomputed, fk_user_author, fk_user_modif, datec, enabled, help) VALUES ('desctotal', 0, 'Total Invoice', 'double', '24,8', 'facture', 0, 0, null, null, 100, '1', 'a:1:{s:7:\"options\";a:1:{s:0:\"\";N;}}', '0',  '0',  TRUE, null, null, 1, 1,'2022-09-08 19:56:34','1', null);

  
