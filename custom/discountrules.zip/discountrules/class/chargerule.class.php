<?php
/* Copyright (C) 2017  Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file        class/chargerule.class.php
 * \ingroup     discountrules
 * \brief       This file is a CRUD class file for ChargeRule (Create/Read/Update/Delete)
 */

// Put here all includes required by your class file
require_once DOL_DOCUMENT_ROOT . '/core/class/commonobject.class.php';
require_once DOL_DOCUMENT_ROOT . '/societe/class/societe.class.php';
require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';
require_once __DIR__ . '/../lib/discountrules.lib.php';
//require_once DOL_DOCUMENT_ROOT . '/societe/class/societe.class.php';
//require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';

/**
 * Class for ChargeRule
 */
class ChargeRule extends CommonObject
{
    /**
     * @var string ID of module.
     */
    public $module = 'discountrules';

    /**
     * @var string ID to identify managed object.
     */
    public $element = 'chargerule';

    /**
     * @var string Name of table without prefix where object is stored. This is also the key used for extrafields management.
     */
    public $table_element = 'discountrules_chargerule';

    /**
     * @var int  Does this object support multicompany module ?
     * 0=No test on entity, 1=Test with field entity, 'field@table'=Test with link by field@table
     */
    public $ismultientitymanaged = 0;

    /**
     * @var int  Does object support extrafields ? 0=No, 1=Yes
     */
    public $isextrafieldmanaged = 1;

    /**
     * @var string String with name of icon for chargerule. Must be the part after the 'object_' into object_chargerule.png
     */
    public $picto = 'chargerule@discountrules';


    const STATUS_DRAFT = 0;
    const STATUS_VALIDATED = 1;
    const STATUS_CANCELED = 9;


    /**
     *  'type' field format ('integer', 'integer:ObjectClass:PathToClass[:AddCreateButtonOrNot[:Filter]]', 'sellist:TableName:LabelFieldName[:KeyFieldName[:KeyFieldParent[:Filter]]]', 'varchar(x)', 'double(24,8)', 'real', 'price', 'text', 'text:none', 'html', 'date', 'datetime', 'timestamp', 'duration', 'mail', 'phone', 'url', 'password')
     *         Note: Filter can be a string like "(t.ref:like:'SO-%') or (t.date_creation:<:'20160101') or (t.nature:is:NULL)"
     *  'label' the translation key.
     *  'picto' is code of a picto to show before value in forms
     *  'enabled' is a condition when the field must be managed (Example: 1 or '$conf->global->MY_SETUP_PARAM)
     *  'position' is the sort order of field.
     *  'notnull' is set to 1 if not null in database. Set to -1 if we must set data to null if empty ('' or 0).
     *  'visible' says if field is visible in list (Examples: 0=Not visible, 1=Visible on list and create/update/view forms, 2=Visible on list only, 3=Visible on create/update/view form only (not list), 4=Visible on list and update/view form only (not create). 5=Visible on list and view only (not create/not update). Using a negative value means field is not shown by default on list but can be selected for viewing)
     *  'noteditable' says if field is not editable (1 or 0)
     *  'default' is a default value for creation (can still be overwrote by the Setup of Default Values if field is editable in creation form). Note: If default is set to '(PROV)' and field is 'ref', the default value will be set to '(PROVid)' where id is rowid when a new record is created.
     *  'index' if we want an index in database.
     *  'foreignkey'=>'tablename.field' if the field is a foreign key (it is recommanded to name the field fk_...).
     *  'searchall' is 1 if we want to search in this field when making a search from the quick search button.
     *  'isameasure' must be set to 1 if you want to have a total on list for this field. Field type must be summable like integer or double(24,8).
     *  'css' and 'cssview' and 'csslist' is the CSS style to use on field. 'css' is used in creation and update. 'cssview' is used in view mode. 'csslist' is used for columns in lists. For example: 'maxwidth200', 'wordbreak', 'tdoverflowmax200'
     *  'help' is a 'TranslationString' to use to show a tooltip on field. You can also use 'TranslationString:keyfortooltiponlick' for a tooltip on click.
     *  'showoncombobox' if value of the field must be visible into the label of the combobox that list record
     *  'disabled' is 1 if we want to have the field locked by a 'disabled' attribute. In most cases, this is never set into the definition of $fields into class, but is set dynamically by some part of code.
     *  'arraykeyval' to set list of value if type is a list of predefined values. For example: array("0"=>"Draft","1"=>"Active","-1"=>"Cancel")
     *  'autofocusoncreate' to have field having the focus on a create form. Only 1 field should have this property set to 1.
     *  'comment' is not used. You can store here any text of your choice. It is not used by application.
     *
     *  Note: To have value dynamic, you can set value to 0 in definition and edit the value on the fly into the constructor.
     */

    // BEGIN MODULEBUILDER PROPERTIES
	/**
	 * @var array  Array with all fields and their property. Do not use it as a static var. It may be modified by constructor.
	 */
	public $fields=array(
		'rowid' => array('type'=>'integer', 'label'=>'TechnicalID', 'enabled'=>'1', 'position'=>1, 'notnull'=>1, 'visible'=>0, 'noteditable'=>'1', 'index'=>1, 'css'=>'left', 'comment'=>"Id"),
        'ref' => array('type'=>'varchar(128)', 'label'=>'Ref', 'enabled'=>'1', 'position'=>1, 'notnull'=>1, 'visible'=>1, 'default'=>'(PROV)', 'index'=>1, 'searchall'=>1, 'showoncombobox'=>'1', 'comment'=>"Reference of object"),
        'entity' => array('type'=>'integer', 'label'=>'Entity', 'enabled'=>'1', 'position'=>20, 'notnull'=>1, 'visible'=>0, 'default'=>'1', 'index'=>1,),
		'label' => array('type'=>'varchar(255)', 'label'=>'Label', 'enabled'=>'1', 'position'=>30, 'notnull'=>0, 'visible'=>1, 'searchall'=>1, 'css'=>'minwidth300', 'help'=>"Help text", 'showoncombobox'=>'1',),
		'fk_soc' => array('type'=>'integer:Societe:societe/class/societe.class.php:1:status=1 AND entity IN (__SHARED_ENTITIES__)', 'label'=>'ThirdParty', 'enabled'=>'1', 'position'=>50, 'notnull'=>-1, 'visible'=>1, 'index'=>1, 'help'=>"LinkToThirparty",),
		'fk_project' => array('type'=>'integer:Project:projet/class/project.class.php:1', 'label'=>'Project', 'enabled'=>'1', 'position'=>52, 'notnull'=>-1, 'visible'=>-1, 'index'=>1,),
		'note_public' => array('type'=>'html', 'label'=>'NotePublic', 'enabled'=>'1', 'position'=>61, 'notnull'=>0, 'visible'=>0,),
		'note_private' => array('type'=>'html', 'label'=>'NotePrivate', 'enabled'=>'1', 'position'=>62, 'notnull'=>0, 'visible'=>0,),
		'date_creation' => array('type'=>'datetime', 'label'=>'DateCreation', 'enabled'=>'1', 'position'=>500, 'notnull'=>1, 'visible'=>-2,),
		'tms' => array('type'=>'timestamp', 'label'=>'DateModification', 'enabled'=>'1', 'position'=>501, 'notnull'=>0, 'visible'=>-2,),
		'fk_user_creat' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserAuthor', 'enabled'=>'1', 'position'=>510, 'notnull'=>1, 'visible'=>-2, 'foreignkey'=>'user.rowid',),
		'fk_user_modif' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserModif', 'enabled'=>'1', 'position'=>511, 'notnull'=>-1, 'visible'=>-2,),
		'last_main_doc' => array('type'=>'varchar(255)', 'label'=>'LastMainDoc', 'enabled'=>'1', 'position'=>600, 'notnull'=>0, 'visible'=>0,),
		'import_key' => array('type'=>'varchar(14)', 'label'=>'ImportId', 'enabled'=>'1', 'position'=>1000, 'notnull'=>-1, 'visible'=>-2,),
		'model_pdf' => array('type'=>'varchar(255)', 'label'=>'Model pdf', 'enabled'=>'1', 'position'=>1010, 'notnull'=>-1, 'visible'=>0,),
		'fk_country' => array('type'=>'integer', 'label'=>'Country', 'enabled'=>'1', 'position'=>80, 'notnull'=>0, 'visible'=>1, 'default'=>'null', 'index'=>1, 'comment'=>"Country ID"),
		'fk_c_typent' => array('type'=>'integer', 'label'=>'ThirdPartyType', 'enabled'=>'1', 'position'=>91, 'notnull'=>0, 'visible'=>1, 'index'=>1,),
		'termfrom' => array('type'=>'datetime', 'label'=>'DatePayFrom', 'enabled'=>'1', 'position'=>100, 'notnull'=>-1, 'visible'=>1, 'help'=>"DatePayFromHelp", 'comment'=>"date from"),
		'termto' => array('type'=>'datetime', 'label'=>'DatePayTo', 'enabled'=>'1', 'position'=>101, 'notnull'=>-1, 'visible'=>1, 'help'=>"DatePayToHelp",),
		'from_quantity' => array('type'=>'integer', 'label'=>'FromQty', 'enabled'=>'1', 'position'=>40, 'notnull'=>0, 'visible'=>1,),
		'to_quantity' => array('type'=>'integer', 'label'=>'ToQty', 'enabled'=>'1', 'position'=>40, 'notnull'=>0, 'visible'=>1,),
        'all_category_product' =>array('type' => 'integer', 'label' => 'ProductCategory', 'enabled' => 1, 'notnull' => -1, 'nullvalue'=>0, 'default' => -1, 'visible' => 1, 'position' => 118, 'help' => 'ProductCategoryHelp' ),
        'all_category_company' =>array('type' => 'integer', 'label' => 'ClientCategory', 'enabled' => 1, 'notnull' => -1, 'nullvalue'=>0, 'default' => -1, 'visible' => 1, 'position' => 119, 'help' => 'ClientCategoryHelp' ),
		'reduction' => array('type'=>'double(24,8)', 'label'=>'ChargePercent', 'enabled'=>'1', 'position'=>70, 'notnull'=>1, 'visible'=>1, 'help'=>"DiscountPercentHelp",),
        'status' => array('type'=>'smallint', 'label'=>'Status', 'enabled'=>'1', 'position'=>1000, 'notnull'=>1, 'visible'=>5, 'default'=>'0', 'index'=>1, 'arrayofkeyval'=>array('0'=>'Draft', '1'=>'Validated', '9'=>'Canceled'),),
    );
	public $rowid;
	public $ref;
	public $entity;
	public $label;
	public $fk_soc;
	public $fk_project;
	public $note_public;
	public $note_private;
	public $date_creation;
	public $tms;
	public $fk_user_creat;
	public $fk_user_modif;
	public $last_main_doc;
	public $import_key;
	public $model_pdf;
	public $fk_country;
	public $fk_c_typent;
	public $termfrom;
	public $termto;
	public $from_quantity;
	public $to_quantity;
	public $reduction;
	public $status;
	public $all_category_product;
	public $all_category_company;
	// END MODULEBUILDER PROPERTIES

    public $TCategoryProduct = array();
    public $TCategoryCompany = array();
    // If this object has a subtable with lines

    // /**
    //  * @var string    Name of subtable line
    //  */
    // public $table_element_line = 'discountrules_chargeruleline';

    // /**
    //  * @var string    Field with ID of parent key if this object has a parent
    //  */
    // public $fk_element = 'fk_chargerule';

    // /**
    //  * @var string    Name of subtable class that manage subtable lines
    //  */
    // public $class_element_line = 'ChargeRuleline';

    // /**
    //  * @var array	List of child tables. To test if we can delete object.
    //  */
    // protected $childtables = array();

    // /**
    //  * @var array    List of child tables. To know object to delete on cascade.
    //  *               If name matches '@ClassNAme:FilePathClass;ParentFkFieldName' it will
    //  *               call method deleteByParentField(parentId, ParentFkFieldName) to fetch and delete child object
    //  */
    // protected $childtablesoncascade = array('discountrules_chargeruledet');

    // /**
    //  * @var ChargeRuleLine[]     Array of subtable lines
    //  */
    // public $lines = array();


    /**
     * Constructor
     *
     * @param DoliDb $db Database handler
     */
    public function __construct(DoliDB $db)
    {
        global $conf, $langs;

        $this->db = $db;

        if (empty($conf->global->MAIN_SHOW_TECHNICAL_ID) && isset($this->fields['rowid'])) $this->fields['rowid']['visible'] = 0;
        if (empty($conf->multicompany->enabled) && isset($this->fields['entity'])) $this->fields['entity']['enabled'] = 0;

        // Example to show how to set values of fields definition dynamically
        /*if ($user->rights->discountrules->chargerule->read) {
            $this->fields['myfield']['visible'] = 1;
            $this->fields['myfield']['noteditable'] = 0;
        }*/

        // Unset fields that are disabled
        foreach ($this->fields as $key => $val) {
            if (isset($val['enabled']) && empty($val['enabled'])) {
                unset($this->fields[$key]);
            }
        }

        // Translate some data of arrayofkeyval
        if (is_object($langs)) {
            foreach ($this->fields as $key => $val) {
                if (!empty($val['arrayofkeyval']) && is_array($val['arrayofkeyval'])) {
                    foreach ($val['arrayofkeyval'] as $key2 => $val2) {
                        $this->fields[$key]['arrayofkeyval'][$key2] = $langs->trans($val2);
                    }
                }
            }
        }
    }

    /**
     * Create object into database
     *
     * @param User $user User that creates
     * @param bool $notrigger false=launch triggers after, true=disable triggers
     * @return int             <0 if KO, Id of created object if OK
     */
    public function create(User $user, $notrigger = false)
    {
        return $this->createCommon($user, $notrigger);
    }
    public function showInputField($val, $key, $value, $moreparam = '', $keysuffix = '', $keyprefix = '', $morecss = 0, $nonewbutton = 0)
    {
        global $conf, $langs, $form, $user;

        if ($conf->categorie->enabled) {
            include_once DOL_DOCUMENT_ROOT . '/categories/class/categorie.class.php';
        }

        // Load langs
        if(!empty($this->fields[$key]['langfile'])){
            if (is_array($this->fields[$key]['langfile'])) $langs->loadLangs($this->fields[$key]['langfile']);
            else $langs->load($this->fields[$key]['langfile']);
        }

        if(empty($form)){ $form=new Form($this->db); }

        $required = '';
        if(!empty($this->fields[$key]['notnull']) && abs($this->fields[$key]['notnull']) > 0){
            $required = ' required ';
        }

        if ($key == 'fk_country'){
            $out = $form->select_country($value, $keyprefix.$key.$keysuffix);
        }
        elseif ($key == 'fk_product'){
            // pas de modification possible pour eviter les MEGA GROSSES BOULETTES utilisateur
            $out = $this->showOutputFieldQuick($key, $moreparam, $keysuffix, $keyprefix, $morecss);
        }
        elseif ($key == 'fk_c_typent'){
            require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
            $formcompany = new FormCompany($this->db);
            $sortparam = (empty($conf->global->SOCIETE_SORT_ON_TYPEENT) ? 'ASC' : $conf->global->SOCIETE_SORT_ON_TYPEENT); // NONE means we keep sort of original array, so we sort on position. ASC, means next function will sort on label.
            $TTypent = $formcompany->typent_array(0);
            //$TTypent[0] = $langs->trans('AllTypeEnt');
            $out = Form::selectarray("fk_c_typent", $TTypent, $this->fk_c_typent, 1, 0, 0, '', 0, 0, 0, $sortparam);
            if ($user->admin) $out.=' '.info_admin($langs->trans("YouCanChangeValuesForThisListFromDictionarySetup"), 1);
        }
        elseif ($key == 'all_category_product'){
            // Petite astuce car je ne peux pas creer de input pour les categories donc je les ajoutent l�
            $out = $this->generateFormCategorie('product',$keyprefix.'TCategoryProduct'.$keysuffix, $this->TCategoryProduct);
        }
        elseif ($key == 'all_category_company'){
            // Petite astuce car je ne peux pas creer de input pour les categories donc je les ajoutent l�
            $out = $this->generateFormCategorie('customer',$keyprefix.'TCategoryCompany'.$keysuffix, $this->TCategoryCompany);
        }

        elseif ($key == 'priority_rank'){
            $options = array();
            foreach ($this->fields['priority_rank']['arrayofkeyval'] as $arraykey => $arrayval) {
                $options[$arraykey] = $langs->trans($arrayval);
            }
            $out = Form::selectarray($keyprefix.$key.$keysuffix, $options,$value);
        }
        elseif (in_array($key, array('reduction', 'product_price', 'product_reduction_amount')))
        {
            $out = '<input '.' class="flat" type="number" name="'.$keyprefix.$key.$keysuffix.'" value="'.$value.'" placeholder="xx.xx" min="0" step="any" >';
        }
        elseif ($key == 'from_quantity')
        {
            $out = '<input '.$required.' class="flat" type="number" name="'.$keyprefix.$key.$keysuffix.'" value="'.$value.'" placeholder="xx" min="0" step="any" >';
        }
        elseif ($this->fields[$key]['type'] == 'date')
        {
            if(is_int($value) && !empty($value)){$value = date('Y-m-d',$value);}
            $out = '<input '.$required.' class="flat" type="date" name="'.$keyprefix.$key.$keysuffix.'" value="'.$value.'" >';
        }
        else
        {
            $out = parent::showInputField($val, $key, $value, $moreparam, $keysuffix, $keyprefix, $morecss, $nonewbutton);
        }


        return $out;
    }

    public function generateFormCategorie($type,$name,$selected=array())
    {
        global $form;
        $TOptions = $form->select_all_categories($type, $selected, $name, 0, 0, 1);
        return  $form->multiselectarray($name, $TOptions, $selected, 0, 0, 'minwidth500', 0, 0, '', '', '', 1);
    }
    public function showOutputFieldQuick($key, $moreparam = '', $keysuffix = '', $keyprefix = '', $morecss = ''){
        return $this->showOutputField($this->fields[$key], $key, $this->{$key}, $moreparam, $keysuffix, $keyprefix, $morecss);
    }
    function update_categoryCompany($replace = false)
    {

        $sql = 'UPDATE '.MAIN_DB_PREFIX.$this->table_element.' SET all_category_company ="'.implode(",",$this->all_category_company).'" WHERE rowid='.$this->id ;
        $resql = $this->db->query($sql);
        if (!$resql){
            dol_print_error($this->db);
            return -3;
        }
        $this->db->free($resql);

        return 1;
    }

    /**
     * 	Get children of line
     *
     * 	@param	int		$id		Id of parent line
     * 	@return	array			Array with list of children lines id
     */
    function fetch_categoryProduct()
    {
        $this->TCategoryProduct=array();

        $sql = 'SELECT * FROM '.MAIN_DB_PREFIX.$this->table_element;
        $sql.= ' WHERE rowid = '.$this->id;

        $resql = $this->db->query($sql);
        if ($resql)
        {
            while ($row = $this->db->fetch_object($resql) )
            {
                $this->TCategoryProduct[] = explode(",",$row->all_category_product);
            }
            $this->db->free($resql);
        }

        return $this->TCategoryProduct;
    }
    function fetch_categoryCompany()
    {
        $this->TCategoryCompany=array();

        $sql = 'SELECT * FROM '.MAIN_DB_PREFIX.$this->table_element;
        $sql.= ' WHERE rowid = '.$this->id;

        $resql = $this->db->query($sql);
        if ($resql)
        {
            while ($row = $this->db->fetch_object($resql) )
            {
                $this->TCategoryCompany[] = explode(",",$row->all_category_company);
            }
            $this->db->free($resql);
        }

        return $this->TCategoryCompany;
    }


    /**
     * @param boolean $replace  if false do not remove cat not in TCategoryProduct
     * @return array
     */
    function update_categoryProduct($replace = false)
    {

        $sql = 'UPDATE '.MAIN_DB_PREFIX.$this->table_element.' SET all_category_product = "'.implode(",",$this->all_category_product).'" WHERE rowid='.$this->id ;
        $resql = $this->db->query($sql);
        if (!$resql){
            dol_print_error($this->db);
            return -3;
        }
        $this->db->free($resql);

        return 1;
    }

    /**
     * Return HTML string to show a field into a page
     * Code very similar with showOutputField of extra fields
     *
     * @param  array   $val		       Array of properties of field to show
     * @param  string  $key            Key of attribute
     * @param  string  $value          Preselected value to show (for date type it must be in timestamp format, for amount or price it must be a php numeric value)
     * @param  string  $moreparam      To add more parametes on html input tag
     * @param  string  $keysuffix      Prefix string to add into name and id of field (can be used to avoid duplicate names)
     * @param  string  $keyprefix      Suffix string to add into name and id of field (can be used to avoid duplicate names)
     * @param  mixed   $morecss        Value for css to define size. May also be a numeric.
     * @return string
     */
    public function showOutputField($val, $key, $value, $moreparam = '', $keysuffix = '', $keyprefix = '', $morecss = '')
    {
        global $conf, $langs, $form;

        $out = '';
        if ($key == 'fk_country'){
            if(!empty($value)){
                $tmparray=getCountry($value,'all');
                $out =  $tmparray['label'];
            }
            else{
                $out =  '<span class="discountrule-all-text" >'.$langs->trans('AllCountries').'</span>';
            }
        }
        elseif ($key == 'fk_company' && empty($value)){
            $out =  '<span class="discountrule-all-text" >'.$langs->trans('AllCustomers').'</span>';
        }
        elseif ($key == 'all_category_product'){
            // Petite astuce car je ne peux pas creer de input pour les categories donc je les ajoutent l�
            $out = $this->getCategorieBadgesList($this->TCategoryProduct, $langs->trans('AllProductCategories'));
        }
        elseif ($key == 'all_category_company'){
            // Petite astuce car je ne peux pas creer de input pour les categories donc je les ajoutent l�
            $out = $this->getCategorieBadgesList($this->TCategoryCompany, $langs->trans('AllCustomersCategories'));
        }
        elseif ($key == 'fk_c_typent'){
            $out = getTypeEntLabel($this->fk_c_typent);
            if(!$out){ $out = ''; }
        }
        elseif ($key == 'fk_status'){
            $out =  $this->getLibStatut(5); // to fix dolibarr using 3 instead of 2
        }
        elseif ($key == 'priority_rank'){
            if(isset($this->fields['priority_rank']['arrayofkeyval'][$value])){
                $out = $langs->trans($this->fields['priority_rank']['arrayofkeyval'][$value]);
            }elseif (empty($value)){
                $out = $langs->trans($this->fields['priority_rank']['arrayofkeyval'][0]);
            }
        }
        else{
            $out = parent::showOutputField($val, $key, $value, $moreparam, $keysuffix, $keyprefix, $morecss);
        }

        return $out;
    }


    /**
     * @param $Tcategorie array of category ID
     * @return string
     */
    public function getCategorieBadgesList($Tcategorie, $emptyMsg = ''){
        $toprint = array();
        dol_include_once('categories/class/categorie.class.php');
        foreach($Tcategorie[0] as $cid)
        {
            $c = new Categorie($this->db);
            if($c->fetch($cid)>0)
            {
                $ways = $c->print_all_ways();       // $ways[0] = "ccc2 >> ccc2a >> ccc2a1" with html formated text
                foreach($ways as $way)
                {
                    // Check contrast with background and correct text color
                    $forced_color = 'categtextwhite';
                    if ($c->color)
                    {
                        if (colorIsLight($c->color)) $forced_color = 'categtextblack';
                    }

                    $toprint[] = '<li class="select2-search-choice-dolibarr noborderoncategories '.$forced_color.'"'.($c->color?' style="background: #'.$c->color.';"':' style="background: #aaa"').'>'.img_object('','category').' '.$way.'</li>';
                }
            }
        }

        if(empty($toprint)){
            $toprint[] = '<li class="select2-search-choice-dolibarr noborderoncategories" style="background: #ebebeb">'.$emptyMsg.'</li>';
        }

        return '<div class="select2-container-multi-dolibarr minwidth200" style="width: 90%;"><ul class="select2-choices-dolibarr">'.implode(' ', $toprint).'</ul></div>';
    }

    /**
     *    @param	string|int	            $type				Type of category ('customer', 'supplier', 'contact', 'product', 'member'). Old mode (0, 1, 2, ...) is deprecated.
     *    @param    string		            $name			HTML field name
     *    @param    array		            $selected    		Id of category preselected or 'auto' (autoselect category if there is only one element)
     * 	  @return string
     */

    public function createCommon(User $user, $notrigger = false)
    {

        // null is forbiden
        $this->from_quantity = doubleval($this->from_quantity);

        $res = parent::createCommon($user, $notrigger);
        $error= 0;
        if($res)
        {
            if ($this->update_categoryProduct(1) < 0){
                $error++;
            }

            if ($this->update_categoryCompany(1) < 0){
                $error++;
            }
        }
        else{
            $error++;
        }


        if ($error) {
            return -1 * $error;
        } else {
            return 1;
        }
    }

    /**
     * Update object into database
     *
     * @param  User $user      User that modifies
     * @param  bool $notrigger false=launch triggers after, true=disable triggers
     * @return int             <0 if KO, >0 if OK
     */
    public function updateCommon(User $user, $notrigger = false)
    {
        $error = 0;

        $fieldvalues = $this->set_save_query();
        unset($fieldvalues['rowid']);	// We don't update this field, it is the key to define which record to update.
        unset($fieldvalues['date_creation']);
        unset($fieldvalues['entity']);

        foreach ($fieldvalues as $k => $v) {
            $tmp[] = $k.'='.$this->quote($v, $this->fields[$k]);
        }
        $sql = 'UPDATE '.MAIN_DB_PREFIX.$this->table_element.' SET '.implode( ',', $tmp ).' WHERE rowid='.$this->id ;

        $this->db->begin();
        if (! $error)
        {
            $res = $this->db->query($sql);

            if ($res===false)
            {
                $error++;
            }

            if ($this->update_categoryProduct(1) < 0)
            {
                $error++;
            }

            if ($this->update_categoryCompany(1) < 0)
            {
                $error++;
            }
            $this->db->free($res);
        }

        if (! $error && ! $notrigger) {
            // Call triggers
            $result=$this->call_trigger(strtoupper(get_class($this)).'_MODIFY',$user);
            if ($result < 0) { $error++; } //Do also here what you must do to rollback action if trigger fail
            // End call triggers
        }

        // Commit or rollback
        if ($error) {
            $this->db->rollback();
            return -1 * $error;
        } else {
            $this->db->commit();
            return $this->id;
        }
    }

    /**
     * Function to update current object
     * @param $key
     */
    public function setValueFromPost($key)
    {
        $this->error = '';
        $request = $_POST;

        // prepare data
        if(!is_array($request)){
            $request[$key] = $request;
        }

        // set default value
        $value = '';
        if(isset($request[$key])){
            $value = $request[$key];
        }

        // TODO : implementer l'utilisation de la class Validate introduite en V15 de Dolibarr

        if(isset($this->fields[$key]))
        {
            if($this->fields[$key]['type'] == 'datetime'){
                $value .= ' '. $request[$key.'hour'] .':'.$request[$key.'min'].':'.$request[$key.'sec'];
                $this->setDate($key, $value);
            }
            else if($this->checkFieldType($key, 'date'))
            {
                $this->setDate($key, $value);
            }
            else if( $this->checkFieldType($key, 'array'))
            {
                $this->{$key} = $value;
            }
            else if( $this->checkFieldType($key, 'float') )
            {
                $this->{$key} = (double) price2num($value);
            }
            else if( $this->checkFieldType($key, 'int') ) {
                $this->{$key} = (int) price2num($value);
            }
            else
            {
                $this->{$key} = $value;
            }

            // for query search optimisation (or just working), only save 0 or a real id value and not the -1 empty value used by select form
            if(in_array($key, array('fk_country', 'fk_company', 'fk_project', 'fk_c_typent')) && ( $this->{$key} < 0 || $this->{$key} == '' ) ){
                $this->{$key} = 0;
            }
        }

    }
    private function set_save_query()
    {
        global $conf;

        $queryarray=array();
        foreach ($this->fields as $field=>$info)	// Loop on definition of fields
        {
            // Depending on field type ('datetime', ...)
            if($this->isDate($info))
            {
                if(empty($this->{$field}))
                {
                    $queryarray[$field] = NULL;
                }
                else
                {
                    $queryarray[$field] = $this->db->idate($this->{$field});

                    if($field == 'date_to'){
                        $queryarray[$field] = empty($this->{$field})?'':dol_print_date($this->{$field},"%Y-%m-%d 23:59:59");
                    }

                    if($field == 'date_from'){
                        $queryarray[$field] = empty($this->{$field})?'':dol_print_date($this->{$field},"%Y-%m-%d 00:00:00");
                    }
                }
            }
            else if($this->isArray($info))
            {
                $queryarray[$field] = serialize($this->{$field});
            }
            else if($this->isInt($info))
            {
                if ($field == 'entity' && is_null($this->{$field})) $queryarray[$field]=$conf->entity;
                else
                {
                    $queryarray[$field] = (int) price2num($this->{$field});
                    if (empty($queryarray[$field])) $queryarray[$field]=0;		// May be rest to null later if property 'nullifempty' is on for this field.
                }
            }
            else if($this->isFloat($info))
            {
                $queryarray[$field] = (double) price2num($this->{$field});
                if (empty($queryarray[$field])) $queryarray[$field]=0;
            }
            else
            {
                $queryarray[$field] = $this->{$field};
            }

            if ($info['type'] == 'timestamp' && empty($queryarray[$field])) unset($queryarray[$field]);
            if (! empty($info['nullifempty']) && empty($queryarray[$field])) $queryarray[$field] = null;
        }

        return $queryarray;
    }

    /**
     * Test type of field
     *
     * @param   string  $field  name of field
     * @param   string  $type   type of field to test
     * @return  bool
     */
    private function checkFieldType($field, $type)
    {
        if (isset($this->fields[$field]) && method_exists($this, 'is' . ucfirst($type)))
        {
            return $this->{'is' . ucfirst($type)}($this->fields[$field]);
        }
        else
        {
            return false;
        }
    }


    /**
     * Function to set date in field
     *
     * @param   string  $field  field to set
     * @param   string  $date   formatted date to convert
     * @return                  mixed
     */
    public function setDate($field, $date)
    {
        if (empty($date))
        {
            $this->{$field} = '';
        }
        else
        {
            require_once DOL_DOCUMENT_ROOT.'/core/lib/date.lib.php';
            $this->{$field} = dol_stringtotime($date);
        }

        return $this->{$field};
    }


    /**
     * Add quote to field value if necessary
     *
     * @param 	string|int	$value			Value to protect
     * @param	array		$fieldsentry	Properties of field
     * @return 	string
     */
    protected function quote($value, $fieldsentry)
    {
        if (is_null($value) && isset($fieldsentry['nullvalue'])) return $this->db->escape($fieldsentry['nullvalue']);

        return parent::quote($value, $fieldsentry);
    }
    /**
     * Clone an object into another one
     *
     * @param User $user User that creates
     * @param int $fromid Id of object to clone
     * @return    mixed                New object created, <0 if KO
     */
    public function createFromClone(User $user, $fromid)
    {
        global $langs, $extrafields;
        $error = 0;

        dol_syslog(__METHOD__, LOG_DEBUG);

        $object = new self($this->db);

        $this->db->begin();

        // Load source object
        $result = $object->fetchCommon($fromid);
        if ($result > 0 && !empty($object->table_element_line)) $object->fetchLines();

        // get lines so they will be clone
        //foreach($this->lines as $line)
        //	$line->fetch_optionals();

        // Reset some properties
        unset($object->id);
        unset($object->fk_user_creat);
        unset($object->import_key);

        // Clear fields
        if (property_exists($object, 'ref')) $object->ref = empty($this->fields['ref']['default']) ? "Copy_Of_" . $object->ref : $this->fields['ref']['default'];
        if (property_exists($object, 'label')) $object->label = empty($this->fields['label']['default']) ? $langs->trans("CopyOf") . " " . $object->label : $this->fields['label']['default'];
        if (property_exists($object, 'status')) {
            $object->status = self::STATUS_DRAFT;
        }
        if (property_exists($object, 'date_creation')) {
            $object->date_creation = dol_now();
        }
        if (property_exists($object, 'date_modification')) {
            $object->date_modification = null;
        }
        // ...
        // Clear extrafields that are unique
        if (is_array($object->array_options) && count($object->array_options) > 0) {
            $extrafields->fetch_name_optionals_label($this->table_element);
            foreach ($object->array_options as $key => $option) {
                $shortkey = preg_replace('/options_/', '', $key);
                if (!empty($extrafields->attributes[$this->table_element]['unique'][$shortkey])) {
                    //var_dump($key); var_dump($clonedObj->array_options[$key]); exit;
                    unset($object->array_options[$key]);
                }
            }
        }

        // Create clone
        $object->context['createfromclone'] = 'createfromclone';
        $result = $object->createCommon($user);
        if ($result < 0) {
            $error++;
            $this->error = $object->error;
            $this->errors = $object->errors;
        }

        if (!$error) {
            // copy internal contacts
            if ($this->copy_linked_contact($object, 'internal') < 0) {
                $error++;
            }
        }

        if (!$error) {
            // copy external contacts if same company
            if (property_exists($this, 'socid') && $this->socid == $object->socid) {
                if ($this->copy_linked_contact($object, 'external') < 0)
                    $error++;
            }
        }

        unset($object->context['createfromclone']);

        // End
        if (!$error) {
            $this->db->commit();
            return $object;
        } else {
            $this->db->rollback();
            return -1;
        }
    }

    /**
     * Load object in memory from the database
     *
     * @param int $id Id object
     * @param string $ref Ref
     * @return int         <0 if KO, 0 if not found, >0 if OK
     */

        public function fetch($id, $ref = null)
    {
        $return = parent::fetchCommon($id,$ref);

        if($return > 0){
            $this->fetch_categoryCompany();
            $this->fetch_categoryProduct();
           // $this->initFieldsParams();
        }

        return $return;
    }


    /**
     * Load object lines in memory from the database
     *
     * @return int         <0 if KO, 0 if not found, >0 if OK
     */
    public function fetchLines()
    {
        $this->lines = array();

        $result = $this->fetchLinesCommon();
        return $result;
    }


    /**
     * Load list of objects in memory from the database.
     *
     * @param string $sortorder Sort Order
     * @param string $sortfield Sort field
     * @param int $limit limit
     * @param int $offset Offset
     * @param array $filter Filter array. Example array('field'=>'valueforlike', 'customurl'=>...)
     * @param string $filtermode Filter mode (AND or OR)
     * @return array|int                 int <0 if KO, array of pages if OK
     */
    public function fetchAll($sortorder = '', $sortfield = '', $limit = 0, $offset = 0, array $filter = array(), $filtermode = 'AND')
    {
        global $conf;

        dol_syslog(__METHOD__, LOG_DEBUG);

        $records = array();

        $sql = 'SELECT ';
        $sql .= $this->getFieldList();
        $sql .= ' FROM ' . MAIN_DB_PREFIX . $this->table_element . ' as t';
        if (isset($this->ismultientitymanaged) && $this->ismultientitymanaged == 1) $sql .= ' WHERE t.entity IN (' . getEntity($this->table_element) . ')';
        else $sql .= ' WHERE 1 = 1';
        // Manage filter
        $sqlwhere = array();
        if (count($filter) > 0) {
            foreach ($filter as $key => $value) {
                if ($key == 't.rowid') {
                    $sqlwhere[] = $key . '=' . $value;
                } elseif (in_array($this->fields[$key]['type'], array('date', 'datetime', 'timestamp'))) {
                    $sqlwhere[] = $key . ' = \'' . $this->db->idate($value) . '\'';
                } elseif ($key == 'customsql') {
                    $sqlwhere[] = $value;
                } elseif (strpos($value, '%') === false) {
                    $sqlwhere[] = $key . ' IN (' . $this->db->sanitize($this->db->escape($value)) . ')';
                } else {
                    $sqlwhere[] = $key . ' LIKE \'%' . $this->db->escape($value) . '%\'';
                }
            }
        }
        if (count($sqlwhere) > 0) {
            $sql .= ' AND (' . implode(' ' . $filtermode . ' ', $sqlwhere) . ')';
        }

        if (!empty($sortfield)) {
            $sql .= $this->db->order($sortfield, $sortorder);
        }
        if (!empty($limit)) {
            $sql .= ' ' . $this->db->plimit($limit, $offset);
        }

        $resql = $this->db->query($sql);
        if ($resql) {
            $num = $this->db->num_rows($resql);
            $i = 0;
            while ($i < ($limit ? min($limit, $num) : $num)) {
                $obj = $this->db->fetch_object($resql);

                $record = new self($this->db);
                $record->setVarsFromFetchObj($obj);

                $records[$record->id] = $record;

                $i++;
            }
            $this->db->free($resql);

            return $records;
        } else {
            $this->errors[] = 'Error ' . $this->db->lasterror();
            dol_syslog(__METHOD__ . ' ' . join(',', $this->errors), LOG_ERR);

            return -1;
        }
    }

    /**
     * Update object into database
     *
     * @param User $user User that modifies
     * @param bool $notrigger false=launch triggers after, true=disable triggers
     * @return int             <0 if KO, >0 if OK
     */
    public function update(User $user, $notrigger = false)
    {
        return $this->updateCommon($user, $notrigger);
    }

    /**
     * Delete object in database
     *
     * @param User $user User that deletes
     * @param bool $notrigger false=launch triggers after, true=disable triggers
     * @return int             <0 if KO, >0 if OK
     */
    public function delete(User $user, $notrigger = false)
    {
        return $this->deleteCommon($user, $notrigger);
        //return $this->deleteCommon($user, $notrigger, 1);
    }

    /**
     *  Delete a line of object in database
     *
     * @param User $user User that delete
     * @param int $idline Id of line to delete
     * @param bool $notrigger false=launch triggers after, true=disable triggers
     * @return int                >0 if OK, <0 if KO
     */
    public function deleteLine(User $user, $idline, $notrigger = false)
    {
        if ($this->status < 0) {
            $this->error = 'ErrorDeleteLineNotAllowedByObjectStatus';
            return -2;
        }

        return $this->deleteLineCommon($user, $idline, $notrigger);
    }


    /**
     *    Validate object
     *
     * @param User $user User making status change
     * @param int $notrigger 1=Does not execute triggers, 0= execute triggers
     * @return    int                        <=0 if OK, 0=Nothing done, >0 if KO
     */
    public function validate($user, $notrigger = 0)
    {
        global $conf, $langs;

        require_once DOL_DOCUMENT_ROOT . '/core/lib/files.lib.php';

        $error = 0;

        // Protection
        if ($this->status == self::STATUS_VALIDATED) {
            dol_syslog(get_class($this) . "::validate action abandonned: already validated", LOG_WARNING);
            return 0;
        }

        /*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->discountrules->chargerule->write))
         || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->discountrules->chargerule->chargerule_advance->validate))))
         {
         $this->error='NotEnoughPermissions';
         dol_syslog(get_class($this)."::valid ".$this->error, LOG_ERR);
         return -1;
         }*/

        $now = dol_now();

        $this->db->begin();

        // Define new ref
        if (!$error && (preg_match('/^[\(]?PROV/i', $this->ref) || empty($this->ref))) // empty should not happened, but when it occurs, the test save life
        {
            $num = $this->getNextNumRef();
        } else {
            $num = $this->ref;
        }
        $this->newref = $num;

        if (!empty($num)) {
            // Validate
            $sql = "UPDATE " . MAIN_DB_PREFIX . $this->table_element;
            $sql .= " SET ref = '" . $this->db->escape($num) . "',";
            $sql .= " status = " . self::STATUS_VALIDATED;
            if (!empty($this->fields['date_validation'])) $sql .= ", date_validation = '" . $this->db->idate($now) . "'";
            if (!empty($this->fields['fk_user_valid'])) $sql .= ", fk_user_valid = " . $user->id;
            $sql .= " WHERE rowid = " . $this->id;

            dol_syslog(get_class($this) . "::validate()", LOG_DEBUG);
            $resql = $this->db->query($sql);
            if (!$resql) {
                dol_print_error($this->db);
                $this->error = $this->db->lasterror();
                $error++;
            }

            if (!$error && !$notrigger) {
                // Call trigger
                $result = $this->call_trigger('CHARGERULE_VALIDATE', $user);
                if ($result < 0) $error++;
                // End call triggers
            }
        }

        if (!$error) {
            $this->oldref = $this->ref;

            // Rename directory if dir was a temporary ref
            if (preg_match('/^[\(]?PROV/i', $this->ref)) {
                // Now we rename also files into index
                $sql = 'UPDATE ' . MAIN_DB_PREFIX . "ecm_files set filename = CONCAT('" . $this->db->escape($this->newref) . "', SUBSTR(filename, " . (strlen($this->ref) + 1) . ")), filepath = 'chargerule/" . $this->db->escape($this->newref) . "'";
                $sql .= " WHERE filename LIKE '" . $this->db->escape($this->ref) . "%' AND filepath = 'chargerule/" . $this->db->escape($this->ref) . "' and entity = " . $conf->entity;
                $resql = $this->db->query($sql);
                if (!$resql) {
                    $error++;
                    $this->error = $this->db->lasterror();
                }

                // We rename directory ($this->ref = old ref, $num = new ref) in order not to lose the attachments
                $oldref = dol_sanitizeFileName($this->ref);
                $newref = dol_sanitizeFileName($num);
                $dirsource = $conf->discountrules->dir_output . '/chargerule/' . $oldref;
                $dirdest = $conf->discountrules->dir_output . '/chargerule/' . $newref;
                if (!$error && file_exists($dirsource)) {
                    dol_syslog(get_class($this) . "::validate() rename dir " . $dirsource . " into " . $dirdest);

                    if (@rename($dirsource, $dirdest)) {
                        dol_syslog("Rename ok");
                        // Rename docs starting with $oldref with $newref
                        $listoffiles = dol_dir_list($conf->discountrules->dir_output . '/chargerule/' . $newref, 'files', 1, '^' . preg_quote($oldref, '/'));
                        foreach ($listoffiles as $fileentry) {
                            $dirsource = $fileentry['name'];
                            $dirdest = preg_replace('/^' . preg_quote($oldref, '/') . '/', $newref, $dirsource);
                            $dirsource = $fileentry['path'] . '/' . $dirsource;
                            $dirdest = $fileentry['path'] . '/' . $dirdest;
                            @rename($dirsource, $dirdest);
                        }
                    }
                }
            }
        }

        // Set new ref and current status
        if (!$error) {
            $this->ref = $num;
            $this->status = self::STATUS_VALIDATED;
        }

        if (!$error) {
            $this->db->commit();
            return 1;
        } else {
            $this->db->rollback();
            return -1;
        }
    }


    /**
     *    Set draft status
     *
     * @param User $user Object user that modify
     * @param int $notrigger 1=Does not execute triggers, 0=Execute triggers
     * @return    int                        <0 if KO, >0 if OK
     */
    public function setDraft($user, $notrigger = 0)
    {
        // Protection
        if ($this->status <= self::STATUS_DRAFT) {
            return 0;
        }

        /*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->discountrules->write))
         || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->discountrules->discountrules_advance->validate))))
         {
         $this->error='Permission denied';
         return -1;
         }*/

        return $this->setStatusCommon($user, self::STATUS_DRAFT, $notrigger, 'CHARGERULE_UNVALIDATE');
    }

    /**
     *    Set cancel status
     *
     * @param User $user Object user that modify
     * @param int $notrigger 1=Does not execute triggers, 0=Execute triggers
     * @return    int                        <0 if KO, 0=Nothing done, >0 if OK
     */
    public function cancel($user, $notrigger = 0)
    {
        // Protection
        if ($this->status != self::STATUS_VALIDATED) {
            return 0;
        }

        /*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->discountrules->write))
         || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->discountrules->discountrules_advance->validate))))
         {
         $this->error='Permission denied';
         return -1;
         }*/

        return $this->setStatusCommon($user, self::STATUS_CANCELED, $notrigger, 'CHARGERULE_CANCEL');
    }

    /**
     *    Set back to validated status
     *
     * @param User $user Object user that modify
     * @param int $notrigger 1=Does not execute triggers, 0=Execute triggers
     * @return    int                        <0 if KO, 0=Nothing done, >0 if OK
     */
    public function reopen($user, $notrigger = 0)
    {
        // Protection
        if ($this->status != self::STATUS_CANCELED) {
            return 0;
        }

        /*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->discountrules->write))
         || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->discountrules->discountrules_advance->validate))))
         {
         $this->error='Permission denied';
         return -1;
         }*/

        return $this->setStatusCommon($user, self::STATUS_VALIDATED, $notrigger, 'CHARGERULE_REOPEN');
    }

    /**
     *  Return a link to the object card (with optionaly the picto)
     *
     * @param int $withpicto Include picto in link (0=No picto, 1=Include picto into link, 2=Only picto)
     * @param string $option On what the link point to ('nolink', ...)
     * @param int $notooltip 1=Disable tooltip
     * @param string $morecss Add more css on link
     * @param int $save_lastsearch_value -1=Auto, 0=No save of lastsearch_values when clicking, 1=Save lastsearch_values whenclicking
     * @return    string                              String with URL
     */
    public function getNomUrl($withpicto = 0, $option = '', $notooltip = 0, $morecss = '', $save_lastsearch_value = -1)
    {
        global $conf, $langs, $hookmanager;

        if (!empty($conf->dol_no_mouse_hover)) $notooltip = 1; // Force disable tooltips

        $result = '';

        $label = img_picto('', $this->picto) . ' <u>' . $langs->trans("ChargeRule") . '</u>';
        if (isset($this->status)) {
            $label .= ' ' . $this->getLibStatut(5);
        }
        $label .= '<br>';
        $label .= '<b>' . $langs->trans('Ref') . ':</b> ' . $this->ref;

        $url = dol_buildpath('/discountrules/chargerule_card.php', 1) . '?id=' . $this->id;

        if ($option != 'nolink') {
            // Add param to save lastsearch_values or not
            $add_save_lastsearch_values = ($save_lastsearch_value == 1 ? 1 : 0);
            if ($save_lastsearch_value == -1 && preg_match('/list\.php/', $_SERVER["PHP_SELF"])) $add_save_lastsearch_values = 1;
            if ($add_save_lastsearch_values) $url .= '&save_lastsearch_values=1';
        }

        $linkclose = '';
        if (empty($notooltip)) {
            if (!empty($conf->global->MAIN_OPTIMIZEFORTEXTBROWSER)) {
                $label = $langs->trans("ShowChargeRule");
                $linkclose .= ' alt="' . dol_escape_htmltag($label, 1) . '"';
            }
            $linkclose .= ' title="' . dol_escape_htmltag($label, 1) . '"';
            $linkclose .= ' class="classfortooltip' . ($morecss ? ' ' . $morecss : '') . '"';
        } else $linkclose = ($morecss ? ' class="' . $morecss . '"' : '');

        $linkstart = '<a href="' . $url . '"';
        $linkstart .= $linkclose . '>';
        $linkend = '</a>';

        $result .= $linkstart;

        if (empty($this->showphoto_on_popup)) {
            if ($withpicto) $result .= img_object(($notooltip ? '' : $label), ($this->picto ? $this->picto : 'generic'), ($notooltip ? (($withpicto != 2) ? 'class="paddingright"' : '') : 'class="' . (($withpicto != 2) ? 'paddingright ' : '') . 'classfortooltip"'), 0, 0, $notooltip ? 0 : 1);
        } else {
            if ($withpicto) {
                require_once DOL_DOCUMENT_ROOT . '/core/lib/files.lib.php';

                list($class, $module) = explode('@', $this->picto);
                $upload_dir = $conf->$module->multidir_output[$conf->entity] . "/$class/" . dol_sanitizeFileName($this->ref);
                $filearray = dol_dir_list($upload_dir, "files");
                $filename = $filearray[0]['name'];
                if (!empty($filename)) {
                    $pospoint = strpos($filearray[0]['name'], '.');

                    $pathtophoto = $class . '/' . $this->ref . '/thumbs/' . substr($filename, 0, $pospoint) . '_mini' . substr($filename, $pospoint);
                    if (empty($conf->global->{strtoupper($module . '_' . $class) . '_FORMATLISTPHOTOSASUSERS'})) {
                        $result .= '<div class="floatleft inline-block valignmiddle divphotoref"><div class="photoref"><img class="photo' . $module . '" alt="No photo" border="0" src="' . DOL_URL_ROOT . '/viewimage.php?modulepart=' . $module . '&entity=' . $conf->entity . '&file=' . urlencode($pathtophoto) . '"></div></div>';
                    } else {
                        $result .= '<div class="floatleft inline-block valignmiddle divphotoref"><img class="photouserphoto userphoto" alt="No photo" border="0" src="' . DOL_URL_ROOT . '/viewimage.php?modulepart=' . $module . '&entity=' . $conf->entity . '&file=' . urlencode($pathtophoto) . '"></div>';
                    }

                    $result .= '</div>';
                } else {
                    $result .= img_object(($notooltip ? '' : $label), ($this->picto ? $this->picto : 'generic'), ($notooltip ? (($withpicto != 2) ? 'class="paddingright"' : '') : 'class="' . (($withpicto != 2) ? 'paddingright ' : '') . 'classfortooltip"'), 0, 0, $notooltip ? 0 : 1);
                }
            }
        }

        if ($withpicto != 2) $result .= $this->ref;

        $result .= $linkend;
        //if ($withpicto != 2) $result.=(($addlabel && $this->label) ? $sep . dol_trunc($this->label, ($addlabel > 1 ? $addlabel : 0)) : '');

        global $action, $hookmanager;
        $hookmanager->initHooks(array('chargeruledao'));
        $parameters = array('id' => $this->id, 'getnomurl' => $result);
        $reshook = $hookmanager->executeHooks('getNomUrl', $parameters, $this, $action); // Note that $action and $object may have been modified by some hooks
        if ($reshook > 0) $result = $hookmanager->resPrint;
        else $result .= $hookmanager->resPrint;

        return $result;
    }

    /**
     *  Return the label of the status
     *
     * @param int $mode 0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
     * @return    string                   Label of status
     */
    public function getLibStatut($mode = 0)
    {
        return $this->LibStatut($this->status, $mode);
    }

    // phpcs:disable PEAR.NamingConventions.ValidFunctionName.ScopeNotCamelCaps

    /**
     *  Return the status
     *
     * @param int $status Id status
     * @param int $mode 0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
     * @return string                   Label of status
     */
    public function LibStatut($status, $mode = 0)
    {
        // phpcs:enable
        if (empty($this->labelStatus) || empty($this->labelStatusShort)) {
            global $langs;
            //$langs->load("discountrules@discountrules");
            $this->labelStatus[self::STATUS_DRAFT] = $langs->trans('Draft');
            $this->labelStatus[self::STATUS_VALIDATED] = $langs->trans('Enabled');
            $this->labelStatus[self::STATUS_CANCELED] = $langs->trans('Disabled');
            $this->labelStatusShort[self::STATUS_DRAFT] = $langs->trans('Draft');
            $this->labelStatusShort[self::STATUS_VALIDATED] = $langs->trans('Enabled');
            $this->labelStatusShort[self::STATUS_CANCELED] = $langs->trans('Disabled');
        }

        $statusType = 'status' . $status;
        //if ($status == self::STATUS_VALIDATED) $statusType = 'status1';
        if ($status == self::STATUS_CANCELED) $statusType = 'status6';

        return dolGetStatus($this->labelStatus[$status], $this->labelStatusShort[$status], '', $statusType, $mode);
    }

    /**
     *    Load the info information in the object
     *
     * @param int $id Id of object
     * @return    void
     */
    public function info($id)
    {
        $sql = 'SELECT rowid, date_creation as datec, tms as datem,';
        $sql .= ' fk_user_creat, fk_user_modif';
        $sql .= ' FROM ' . MAIN_DB_PREFIX . $this->table_element . ' as t';
        $sql .= ' WHERE t.rowid = ' . $id;
        $result = $this->db->query($sql);
        if ($result) {
            if ($this->db->num_rows($result)) {
                $obj = $this->db->fetch_object($result);
                $this->id = $obj->rowid;
                if ($obj->fk_user_author) {
                    $cuser = new User($this->db);
                    $cuser->fetch($obj->fk_user_author);
                    $this->user_creation = $cuser;
                }

                if ($obj->fk_user_valid) {
                    $vuser = new User($this->db);
                    $vuser->fetch($obj->fk_user_valid);
                    $this->user_validation = $vuser;
                }

                if ($obj->fk_user_cloture) {
                    $cluser = new User($this->db);
                    $cluser->fetch($obj->fk_user_cloture);
                    $this->user_cloture = $cluser;
                }

                $this->date_creation = $this->db->jdate($obj->datec);
                $this->date_modification = $this->db->jdate($obj->datem);
                $this->date_validation = $this->db->jdate($obj->datev);
            }

            $this->db->free($result);
        } else {
            dol_print_error($this->db);
        }
    }

    /**
     * Initialise object with example values
     * Id must be 0 if object instance is a specimen
     *
     * @return void
     */
    public function initAsSpecimen()
    {
        $this->initAsSpecimenCommon();
    }

    /**
     *    Create an array of lines
     *
     * @return array|int        array of lines if OK, <0 if KO
     */
    public function getLinesArray()
    {
        $this->lines = array();

        $objectline = new ChargeRuleLine($this->db);
        $result = $objectline->fetchAll('ASC', 'position', 0, 0, array('customsql' => 'fk_chargerule = ' . $this->id));

        if (is_numeric($result)) {
            $this->error = $this->error;
            $this->errors = $this->errors;
            return $result;
        } else {
            $this->lines = $result;
            return $this->lines;
        }
    }

    /**
     *  Returns the reference to the following non used object depending on the active numbering module.
     *
     * @return string            Object free reference
     */
    public function getNextNumRef()
    {
        global $langs, $conf;
        $langs->load("discountrules@discountrules");

        if (empty($conf->global->DISCOUNTRULES_CHARGERULE_ADDON)) {
            $conf->global->DISCOUNTRULES_CHARGERULE_ADDON = 'mod_chargerule_standard';
        }

        if (!empty($conf->global->DISCOUNTRULES_CHARGERULE_ADDON)) {
            $mybool = false;

            $file = $conf->global->DISCOUNTRULES_CHARGERULE_ADDON . ".php";
            $classname = $conf->global->DISCOUNTRULES_CHARGERULE_ADDON;

            // Include file with class
            $dirmodels = array_merge(array('/'), (array)$conf->modules_parts['models']);
            foreach ($dirmodels as $reldir) {
                $dir = dol_buildpath($reldir . "core/modules/discountrules/");

                // Load file with numbering class (if found)
                $mybool |= @include_once $dir . $file;
            }

            if ($mybool === false) {
                dol_print_error('', "Failed to include file " . $file);
                return '';
            }

            if (class_exists($classname)) {
                $obj = new $classname();
                $numref = $obj->getNextValue($this);

                if ($numref != '' && $numref != '-1') {
                    return $numref;
                } else {
                    $this->error = $obj->error;
                    //dol_print_error($this->db,get_class($this)."::getNextNumRef ".$obj->error);
                    return "";
                }
            } else {
                print $langs->trans("Error") . " " . $langs->trans("ClassNotFound") . ' ' . $classname;
                return "";
            }
        } else {
            print $langs->trans("ErrorNumberingModuleNotSetup", $this->element);
            return "";
        }
    }

    /**
     *  Create a document onto disk according to template module.
     *
     * @param string $modele Force template to use ('' to not force)
     * @param Translate $outputlangs objet lang a utiliser pour traduction
     * @param int $hidedetails Hide details of lines
     * @param int $hidedesc Hide description
     * @param int $hideref Hide ref
     * @param null|array $moreparams Array to provide more information
     * @return     int                        0 if KO, 1 if OK
     */
    public function generateDocument($modele, $outputlangs, $hidedetails = 0, $hidedesc = 0, $hideref = 0, $moreparams = null)
    {
        global $conf, $langs;

        $result = 0;
        $includedocgeneration = 0;

        $langs->load("discountrules@discountrules");

        if (!dol_strlen($modele)) {
            $modele = 'standard_chargerule';

            if (!empty($this->model_pdf)) {
                $modele = $this->model_pdf;
            } elseif (!empty($conf->global->CHARGERULE_ADDON_PDF)) {
                $modele = $conf->global->CHARGERULE_ADDON_PDF;
            }
        }

        $modelpath = "core/modules/discountrules/doc/";

        if ($includedocgeneration && !empty($modele)) {
            $result = $this->commonGenerateDocument($modelpath, $modele, $outputlangs, $hidedetails, $hidedesc, $hideref, $moreparams);
        }

        return $result;
    }

    /**
     * Action executed by scheduler
     * CAN BE A CRON TASK. In such a case, parameters come from the schedule job setup field 'Parameters'
     * Use public function doScheduledJob($param1, $param2, ...) to get parameters
     *
     * @return    int            0 if OK, <>0 if KO (this function is used also by cron so only 0 is OK)
     */
    public function doScheduledJob()
    {
        global $conf, $langs;

        //$conf->global->SYSLOG_FILE = 'DOL_DATA_ROOT/dolibarr_mydedicatedlofile.log';

        $error = 0;
        $this->output = '';
        $this->error = '';

        dol_syslog(__METHOD__, LOG_DEBUG);

        $now = dol_now();

        $this->db->begin();

        // ...

        $this->db->commit();

        return $error;
    }
}


require_once DOL_DOCUMENT_ROOT . '/core/class/commonobjectline.class.php';

/**
 * Class ChargeRuleLine. You can also remove this and generate a CRUD class for lines objects.
 */
class ChargeRuleLine extends CommonObjectLine
{
    // To complete with content of an object ChargeRuleLine
    // We should have a field rowid, fk_chargerule and position

    /**
     * @var int  Does object support extrafields ? 0=No, 1=Yes
     */
    public $isextrafieldmanaged = 0;

    /**
     * Constructor
     *
     * @param DoliDb $db Database handler
     */
    public function __construct(DoliDB $db)
    {
        $this->db = $db;
    }
}
