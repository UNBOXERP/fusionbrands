
# MODULE RÈGLES DE REMISES

Ce module vous permet de gérer simplement vos remises et promotions en fonction de différents critères.

Il vous permet aussi de gérer des tarifs spécifiques pour chaque produit.

## Configuration et gestion

Lors de l'activation du module de nouveaux menu gauche apparaissent dans la rubrique "Produit/Service", 
ils vous permettent créer et de gérer les différentes règles de remises disponibles.

Pour les produits, un nouvel onglet "Règles de prix catalogue" est disponible il permet de 
créer et de gérer les différentes règles de remises spécifiques au produit/service.

## Ordre d'application des règles et priorité

Lorsque plusieurs règles sont en concurrence, c'est la plus avantageuse pour le client qui est retenue.
