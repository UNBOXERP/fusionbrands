# CHANGELOG EMAILCOMMANDE FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 1.0

Initial version
## 1.2

cambios en botones commande
email desde edolibarr
## 1.3
variables _REF_

## 1.4
log y objeto action y commande

## 1.5
langs


##1.6

AGREGARON LANGS   VARIABLES   FIX REF   __REF__
##1.6.1
change langs
variables en subject
##1.6.2

add message confirmation view card color green

edd message error not send email
##1.6.3
changes en messaje fix
##1.6.4
fix
##1.6.5
ya fnciona notificacion

##1.6.6
se uso un trigger para disparar notificacion al validar commande

##1.6.7
adjuntacion de archivos e imagenes
##1.6.8