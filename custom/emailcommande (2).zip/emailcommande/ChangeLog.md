# CHANGELOG EMAILCOMMANDE FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 1.0

Initial version
## 1.2

cambios en botones commande
email desde edolibarr
## 1.3
variables _REF_

## 1.4
log y objeto action y commande
