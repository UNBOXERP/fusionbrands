<?php

/*
 * Copyright (C) 2017-2019-2020 ProgSI (contact@progsi.ma)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * \file kanview/class/abstract_my_table.class.php
 * \ingroup kanview
 * \brief This file is a CRUD class file (Create/Read/Update/Delete)
 * Put some comments here
 */
// Protection (if external user for example)
if (!($conf->kanview->enabled)) {
	accessforbidden('', 0, 0);
	exit();
}

require_once DOL_DOCUMENT_ROOT . '/core/class/commonobject.class.php';

// $build = str_replace('.', '', KANVIEW_VERSION);

/**
 * Class ReqKbInternalProjectContacts
 *
 * Put some comments here
 */
class ReqKbInternalProjectContacts extends CommonObject {

	/**
	 *
	 * @var string module auquel appartient cet objet, ne doit pas être modifié
	 */
	public $modulepart = 'kanview';

	/**
	 * nom du champ id (ex.: 'rowid')
	 */
	public $idfield = 'rowid';

	/**
	 * nom du champ Ref (ex.
	 * : 'ref', 'code')
	 */
	public $reffield = 'rowid';

	/**
	 * nbre total des enregistrements
	 *
	 */
	public $nbtotalofrecords = 0; // voir fetchAll()

	/**/
	public $container = 'kanview';

	/**
	 *
	 * @var ReqKbInternalProjectContactsLine[] Lines
	 */
	public $lines = array();
	// public $prop1;

	public $rowid;
	public $id;
	public $datecreate;
	public $statut;
	public $element_id;
	public $fk_c_type_contact;
	public $fk_socpeople;
	public $projet_rowid;
	public $type_contact_element;
	public $type_contact_source;
	public $type_contact_code;
	public $type_contact_libelle;
	public $type_contact_active;
	public $civility;
	public $lastname;
	public $firstname;
	public $photo;
	public $login;

	// sql where params declarations


	/**
	 */
	// -------------------------------------------- __construct()

	/**
	 * Constructor
	 *
	 * @param DoliDb $db
	 *        	Database handler
	 */
	public function __construct(DoliDB $db) {
		global $langs;
		$this->db = $db;

		// désactivation temporaire du mode ONLY_FULL_GROUP_BY (qui interdit l'utilisation du GROUP BY sans tous les champs de la requête) 
		$sqlTmp1 = "SET SESSION sql_mode=(SELECT REPLACE(@@SESSION.sql_mode,'ONLY_FULL_GROUP_BY,',''));";
		$sqlTmp2 = "SET SESSION sql_mode=(SELECT REPLACE(@@SESSION.sql_mode,'ONLY_FULL_GROUP_BY,',''));";
		$db->query($sqlTmp1);
		$db->query($sqlTmp2);

		return 1;
	}

	// --------------------------------------------------- init()

	/**
	 * Initialise object with example values
	 *
	 * @return void
	 */
	public function init() {
		// $this->prop1 = '';

		$this->rowid								 = '';
		$this->id										 = '';
		$this->datecreate						 = '';
		$this->statut								 = '';
		$this->element_id						 = '';
		$this->fk_c_type_contact		 = '';
		$this->fk_socpeople					 = '';
		$this->projet_rowid					 = '';
		$this->type_contact_element	 = '';
		$this->type_contact_source	 = '';
		$this->type_contact_code		 = '';
		$this->type_contact_libelle	 = '';
		$this->type_contact_active	 = '';
		$this->civility							 = '';
		$this->lastname							 = '';
		$this->firstname						 = '';
		$this->photo								 = '';
		$this->login								 = '';
	}

	// ------------------------------------------------------- fetchOne()

	/**
	 * Load first object in memory from the database
	 *
	 * @return int <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetchOne($_ORDERBY = '', $_isNewOrderBy = true, $_WHERE = '', $_isNewWhere = true, $_HAVING = '', $_isNewHaving = true) {
		dol_syslog(__METHOD__, LOG_DEBUG);

		$sql = $this->getCodeSQL($_ORDERBY, $_isNewOrderBy, $_WHERE, $_isNewWhere, $_HAVING, $_isNewHaving);

		// var_dump($sql);

		$resql = $this->db->query($sql);
		if ($resql) {
			$numrows = $this->db->num_rows($resql);
			if ($numrows) {
				$obj = $this->db->fetch_object($resql);

				// $this->id = $obj->rowid;
				$this->copyObject($obj, $this);
			}

			$this->db->free($resql);

			if ($numrows) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else {
			$this->errors[] = 'Error ' . $this->db->lasterror();
			dol_syslog(__METHOD__ . ' ' . join(',', $this->errors), LOG_ERR);

			return - 1;
		}
	}

	// ------------------------------------------------------- fetchOneByField()

	/**
	 * Load first object in memory from the database by field
	 *
	 * @return int <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetchOneByField($fieldName, $fieldValue) {
		dol_syslog(__METHOD__, LOG_DEBUG);

		$sql					 = $this->getCodeSQL($ORDERBY			 = '', $isNewOrderBy	 = true, $WHERE				 = $fieldName . " = '" . $fieldValue . "' ", $isNewWhere		 = true, $HAVING				 = '', $isNewHaving	 = true);

		// var_dump($sql);

		$resql = $this->db->query($sql);
		if ($resql) {
			$numrows = $this->db->num_rows($resql);
			if ($numrows) {
				$obj = $this->db->fetch_object($resql);

				// $this->id = $obj->rowid;
				$this->copyObject($obj, $this);
			}

			$this->db->free($resql);

			if ($numrows) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else {
			$this->errors[] = 'Error ' . $this->db->lasterror();
			dol_syslog(__METHOD__ . ' ' . join(',', $this->errors), LOG_ERR);

			return - 1;
		}
	}

	// ------------------------------------------------------- fetchById()

	/**
	 * Load first object in memory from the database by Id
	 *
	 * @return int <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetchById($rowid) {
		dol_syslog(__METHOD__, LOG_DEBUG);

		$idField = 'rowid';

		if (empty($idField))
			$idField = 'rowid';

		$sql					 = $this->getCodeSQL($ORDERBY			 = '', $isNewOrderBy	 = true, $WHERE				 = $idField . ' = ' . intval($rowid), $isNewWhere		 = true, $HAVING				 = '', $isNewHaving	 = true);

		// var_dump($sql);

		$resql = $this->db->query($sql);
		if ($resql) {
			$numrows = $this->db->num_rows($resql);
			if ($numrows) {
				$obj = $this->db->fetch_object($resql);

				// $this->id = $obj->rowid;
				$this->copyObject($obj, $this);
			}

			$this->db->free($resql);

			if ($numrows) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else {
			$this->errors[] = 'Error ' . $this->db->lasterror();
			dol_syslog(__METHOD__ . ' ' . join(',', $this->errors), LOG_ERR);

			return - 1;
		}
	}

	// ------------------------------------------------------- fetchByRef()

	/**
	 * Load first object in memory from the database by Ref
	 *
	 * @return int <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetchByRef($ref) {
		dol_syslog(__METHOD__, LOG_DEBUG);

		$refField = 'rowid';

		if (empty($refField))
			$refField = 'ref';

		$sql					 = $this->getCodeSQL($ORDERBY			 = '', $isNewOrderBy	 = true, $WHERE				 = $refField . " = '" . $ref . "' ", $isNewWhere		 = true, $HAVING				 = '', $isNewHaving	 = true);

		// var_dump($sql);

		$resql = $this->db->query($sql);
		if ($resql) {
			$numrows = $this->db->num_rows($resql);
			if ($numrows) {
				$obj = $this->db->fetch_object($resql);

				// $this->id = $obj->rowid;
				$this->copyObject($obj, $this);
			}

			$this->db->free($resql);

			if ($numrows) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else {
			$this->errors[] = 'Error ' . $this->db->lasterror();
			dol_syslog(__METHOD__ . ' ' . join(',', $this->errors), LOG_ERR);

			return - 1;
		}
	}

	// ---------------------------------------------- fetchAll()

	/**
	 * Load object in memory from the database
	 *
	 * @param int $LIMIT
	 *        	Clause LIMIT
	 * @param int $OFFSET
	 *        	Clause OFFSET
	 * @param string $ORDERBY
	 *        	Clause ORDER BY (sans le "ORDER BY", et même syntax que SQL)
	 *        	Ce paramètre, s'il est non vide, est prioritaire sur la clause ORDER BY initialement fourni par la requete de la classe
	 * @return int <0 if KO, number of records if OK
	 */
	public function fetchAll($LIMIT = 0, $OFFSET = 0, $ORDERBY = '', $isNewOrderBy = true, $WHERE = '', $isNewWhere = true, $HAVING = '', $isNewHaving = true) {
		dol_syslog(__METHOD__, LOG_DEBUG);

		global $conf;

		$sql = $this->getCodeSQL($ORDERBY, $isNewOrderBy, $WHERE, $isNewWhere, $HAVING, $isNewHaving);

		// nbre total des enregistrements (avant d'appliquer limit/offset)
		if (empty($conf->global->MAIN_DISABLE_FULL_SCANLIST)) {
			$result									 = $this->db->query($sql);
			if ($result)
				$this->nbtotalofrecords	 = $this->db->num_rows($result);
		}

		if (!empty($LIMIT)) {
			$sql .= ' ' . $this->db->plimit($LIMIT, $OFFSET);
		}

		$this->lines = array();

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);

			while ($obj = $this->db->fetch_object($resql)) {
				$line = new ReqKbInternalProjectContactsLine();

				// $line->id = $obj->rowid;
				$this->copyObject($obj, $line);

				$this->lines[] = $line;
			}

			$this->db->free($resql);

			return $num;
		}
		else {
			$this->errors[] = 'Error ' . $this->db->lasterror();
			dol_syslog(__METHOD__ . ' ' . join(',', $this->errors), LOG_ERR);

			return - 1;
		}
	}

	// -------------------------------------------------- copyObject()

	/**
	 * copie un objet du même type que celui en cours vers un autre objet du meme type sauf l'id
	 *
	 * @param $objSource objet
	 *        	du même type à copier
	 */
	public function copyObject($objSource, $objDest) {

		// $objDest->prop1 = $objSource->prop1;

		$objDest->rowid								 = $objSource->rowid;
		$objDest->id									 = $objSource->id;
		$objDest->datecreate					 = $this->db->jdate($objSource->datecreate);
		$objDest->statut							 = $objSource->statut;
		$objDest->element_id					 = $objSource->element_id;
		$objDest->fk_c_type_contact		 = $objSource->fk_c_type_contact;
		$objDest->fk_socpeople				 = $objSource->fk_socpeople;
		$objDest->projet_rowid				 = $objSource->projet_rowid;
		$objDest->type_contact_element = $objSource->type_contact_element;
		$objDest->type_contact_source	 = $objSource->type_contact_source;
		$objDest->type_contact_code		 = $objSource->type_contact_code;
		$objDest->type_contact_libelle = $objSource->type_contact_libelle;
		$objDest->type_contact_active	 = $objSource->type_contact_active;
		$objDest->civility						 = $objSource->civility;
		$objDest->lastname						 = $objSource->lastname;
		$objDest->firstname						 = $objSource->firstname;
		$objDest->photo								 = $objSource->photo;
		$objDest->login								 = $objSource->login;
		// $objDest->datec = $this->db->jdate($objSource->datec);
		// $objDest->tms = $this->db->jdate($objSource->tms);
	}

	// ------------------------------------------------ getCodeSQL()

	/**
	 * renvoie la clause FROM sans le FROM
	 */
	public function getCodeSQL($_ORDERBY = '', $_isNewOrderBy = true, $_WHERE = '', $_isNewWhere = true, $_HAVING = '', $_isNewHaving = true) {
		$sql = '';

		$sql = "SELECT ";

		$sql .= " " . "t.rowid AS rowid,";
		$sql .= " " . "t.rowid AS id,";
		$sql .= " " . "t.datecreate AS datecreate,";
		$sql .= " " . "t.statut AS statut,";
		$sql .= " " . "t.element_id AS element_id,";
		$sql .= " " . "t.fk_c_type_contact AS fk_c_type_contact,";
		$sql .= " " . "t.fk_socpeople AS fk_socpeople,";
		$sql .= " " . "" . MAIN_DB_PREFIX . "projet.rowid AS projet_rowid,";
		$sql .= " " . "" . MAIN_DB_PREFIX . "c_type_contact.element AS type_contact_element,";
		$sql .= " " . "" . MAIN_DB_PREFIX . "c_type_contact.source AS type_contact_source,";
		$sql .= " " . "" . MAIN_DB_PREFIX . "c_type_contact.code AS type_contact_code,";
		$sql .= " " . "" . MAIN_DB_PREFIX . "c_type_contact.libelle AS type_contact_libelle,";
		$sql .= " " . "" . MAIN_DB_PREFIX . "c_type_contact.active AS type_contact_active,";
		$sql .= " " . "" . MAIN_DB_PREFIX . "user.civility AS civility,";
		$sql .= " " . "" . MAIN_DB_PREFIX . "user.lastname AS lastname,";
		$sql .= " " . "" . MAIN_DB_PREFIX . "user.firstname AS firstname,";
		$sql .= " " . "" . MAIN_DB_PREFIX . "user.photo AS photo,";
		$sql .= " " . "" . MAIN_DB_PREFIX . "user.login AS login";

		$sql .= " FROM ";
		$sql .= "" . MAIN_DB_PREFIX . "element_contact AS t   left join " . MAIN_DB_PREFIX . "projet on t.element_id = " . MAIN_DB_PREFIX . "projet.rowid   left join " . MAIN_DB_PREFIX . "c_type_contact on t.fk_c_type_contact = " . MAIN_DB_PREFIX . "c_type_contact.rowid   left join " . MAIN_DB_PREFIX . "user on t.fk_socpeople = " . MAIN_DB_PREFIX . "user.rowid";

		// --------- WHERE
		$WHERE = "  " . MAIN_DB_PREFIX . "c_type_contact.element = 'project'  and  " . MAIN_DB_PREFIX . "c_type_contact.source = 'internal'";
		$WHERE = trim($WHERE);
		if (!empty($_WHERE)) {
			if ($_isNewWhere)
				$sql .= " WHERE " . $_WHERE; // on remplace le where actuel
			else {
				if ($WHERE !== "") {
					$WHERE = $this->setWhereParams($WHERE);
					$sql	 .= " WHERE " . $WHERE . " AND (" . $_WHERE . ") "; // on ajoute le nouveau where
				}
				else {
					$sql .= " WHERE " . $_WHERE;
				}
			}
		}
		elseif ($WHERE !== "") {
			$WHERE = $this->setWhereParams($WHERE);
			$sql	 .= " WHERE " . $WHERE;
		}

		// ----------- GROUP BY
		$GROUPBY = "";
		$GROUPBY = trim($GROUPBY);
		if ($GROUPBY !== "")
			$sql		 .= " GROUP BY " . $GROUPBY;

		// ----------- HAVING
		$HAVING	 = "";
		$HAVING	 = trim($HAVING);
		if (!empty($_HAVING)) {
			if ($_isNewHaving)
				$sql .= " HAVING " . $_HAVING; // on remplace le having actuel
			else {
				if ($HAVING !== "") {
					$HAVING	 = $this->setHavingParams($HAVING);
					$sql		 .= " HAVING " . $HAVING . " AND (" . $_HAVING . ") "; // on ajoute le nouveau having
				}
				else {
					$sql .= " HAVING " . $_HAVING;
				}
			}
		}
		elseif ($HAVING !== "") {
			$HAVING	 = $this->setHavingParams($HAVING);
			$sql		 .= " HAVING " . $HAVING;
		}

		// ----------- ORDER BY
		$ORDERBY = "";
		$ORDERBY = trim($ORDERBY);
		if (!empty($_ORDERBY)) {
			if ($_isNewOrderBy)
				$sql .= " ORDER BY " . $_ORDERBY; // on remplace l'ancien $ORDERBY par le nouveau $_ORDERBY
			else
			if ($ORDERBY !== "")
				$sql .= " ORDER BY " . $ORDERBY . ", " . $_ORDERBY; // // on ajoute le nouveau $_ORDERBY à l'ancien $ORDERBY
			else
				$sql .= " ORDER BY " . $_ORDERBY;
		}
		elseif ($ORDERBY !== "") {
			$sql .= " ORDER BY " . $ORDERBY;
		}

		return $sql;
	}

	// ---------------------------------------------- setWhereParams()

	/**
	 */
	private function setWhereParams($sqlWhereClause) {
		$where = $sqlWhereClause; // la variable $where est utilisée dans le code du Generator, NE PAS MODIFIER



		return $where;
	}

	// ---------------------------------------------- setHavingParams()

	/**
	 */
	private function setHavingParams($sqlHavingClause) {
		$having = $sqlHavingClause; // la variable $having est utilisée dans le code Generator, NE PAS MODIFIER



		return $having;
	}

	// ---------------------------------------------- initAsSpecimen()

	/**
	 * Initialise object with example values
	 * Id must be 0 if object instance is a specimen
	 *
	 * @return void
	 */
	public function initAsSpecimen() {
		$this->id		 = 0;
		$this->rowid = 0;

		// $this->prop1 = '';
		// __INIT_AS_SPECIMEN__
	}

	// -------------------------------------------------- generateDocument()

	/**
	 * Create a document onto disk accordign to template module.
	 *
	 * @param string $modele
	 *        	Force le mnodele a utiliser ('' to not force)
	 * @param Translate $outputlangs
	 *        	objet lang a utiliser pour traduction
	 * @param int $hidedetails
	 *        	Hide details of lines
	 * @param int $hidedesc
	 *        	Hide description
	 * @param int $hideref
	 *        	Hide ref
	 * @return int 0 if KO, 1 if OK
	 */
	public function generateDocument($modele, $outputlangs, $hidedetails = 0, $hidedesc = 0, $hideref = 0) {
		global $conf, $langs;

		$langs->load("kanview@kanview");

		// Positionne le modele sur le nom du modele a utiliser
		if (!dol_strlen($modele)) {
			if (!empty($conf->global->KANVIEW_ADDON_PDF)) {
				$modele = $conf->global->KANVIEW_ADDON_PDF;
			}
			else {
				$modele = 'generic';
			}
		}

		$modelpath = "core/modules/kanview/doc/";

		return $this->commonGenerateDocument($modelpath, $modele, $outputlangs, $hidedetails, $hidedesc, $hideref);
	}

	//
	// ------------------------------------- toArray()
	//
	// renvoie l'objet au format Array
	public function toArray() {
		$object_array	 = array();
		$fields_array	 = array('rowid', 'id', 'datecreate', 'statut', 'element_id', 'fk_c_type_contact', 'fk_socpeople', 'projet_rowid', 'type_contact_element', 'type_contact_source', 'type_contact_code', 'type_contact_libelle', 'type_contact_active', 'civility', 'lastname', 'firstname', 'photo', 'login',);

		$count = count($fields_array);

		for ($i = 0; $i < $count; $i++) {
			if (property_exists($this, $fields_array[$i])) {
				$object_array[$fields_array[$i]] = $this->{$fields_array[$i]};
			}
		}

		return $object_array;
	}

	//
	// ------------------------------------- toLinesArray()
	//
	// renvoie les lignes de l'objet au format Array
	public function toLinesArray() {
		$lines_array	 = array();
		$fields_array	 = array('rowid', 'id', 'datecreate', 'statut', 'element_id', 'fk_c_type_contact', 'fk_socpeople', 'projet_rowid', 'type_contact_element', 'type_contact_source', 'type_contact_code', 'type_contact_libelle', 'type_contact_active', 'civility', 'lastname', 'firstname', 'photo', 'login',);

		$count = count($fields_array);

		$countlines = count($this->lines);
		for ($j = 0; $j < $countlines; $j++) {
			for ($i = 0; $i < $count; $i++) {
				if (property_exists($this->lines[$j], $fields_array[$i])) {
					$lines_array[$j][$fields_array[$i]] = $this->lines->{$fields_array[$i]};
				}
			}
		}

		return $lines_array;
	}

}

/**
 * Class ReqKbInternalProjectContactsLine
 */
class ReqKbInternalProjectContactsLine {

	/**
	 *
	 * @var string module auquel appartient cet objet, ne doit pas être modifié
	 */
	public $modulepart = 'kanview';

	/**
	 * nom du champ id (ex.: 'rowid')
	 */
	public $idfield = 'rowid';

	/**
	 * nom du champ Ref (ex.
	 * : 'ref', 'code')
	 */
	public $reffield = 'rowid';
	// public $prop1;

	public $rowid;
	public $id;
	public $datecreate;
	public $statut;
	public $element_id;
	public $fk_c_type_contact;
	public $fk_socpeople;
	public $projet_rowid;
	public $type_contact_element;
	public $type_contact_source;
	public $type_contact_code;
	public $type_contact_libelle;
	public $type_contact_active;
	public $civility;
	public $lastname;
	public $firstname;
	public $photo;
	public $login;

}

// *******************************************************************************************************************
//                                                  FIN
// *******************************************************************************************************************






















