# KanView

KanView est un module Dolibarr qui permet d'implémenter des vues Kanban pour les objets Dolibarr
(Projets, Tâches, Commandes, Factures, ...).

Documentation utilisateur : https://doc.progsi.ma/fr/kanview
Démo : https://kanview.progsi.ma
Nos autres modules : https://www.dolistore.com/fr/recherche?controller=search&orderby=position&orderway=desc&search_query=progsi&submit_search=

## LICENCE

KanView est distribué sous les termes de la licence AGPL v3 ou supérieure (voir fichiers COPYING et COPYRIGHT).


## INSTALLER KanView

KanView s'installe dans Dolibarr comme tout autre module.
1- Lorsque vous aurez récupéré le .zip du module, dézippez le dans htdocs ou dans htdocs/custom,
htdocs étant la racine de votre Dolibarr (qui peut avoir un autre nom dans votre installation).
2- Allez dans Accueil > Configuration > Modules/Applications
3- Cherchez l'entrée "Vues Kanban" ou "KanView" dans la liste des modules
4- Activez-le
5- Clickez sur l'option du menu haut "KanView" qui vient d'être ajoutée






