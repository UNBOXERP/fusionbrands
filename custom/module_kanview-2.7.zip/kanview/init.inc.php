<?php

if (!defined('KANVIEW_VERSION'))
	define('KANVIEW_VERSION', '2.7');

include_once(__DIR__ . '/lib/kanview.lib.php');
include_once('rights.php');

